# Workout Page Automation -- Status as of Aug 22, 2026

Sibling project to `recipe-page/`, same automation pattern, new niche:
fitness/workout content for a new TikTok + Instagram + Facebook channel
the user set up. Read `recipe-page/README.md` first if you haven't --
almost everything there (persistence model, Higgsfield reliability notes,
Buffer posting flow, account-safety check) applies here unchanged. This
file only covers what's different.

## Status: channels connected, no posts scheduled yet
As of 2026-08-22 all 3 fitness channels (30secfitness/TikTok,
30sec_fitness/Instagram, Crunch time/Facebook) are created and connected
to Buffer, verified 3/3 in Settings > Channels. Nothing has been posted
or scheduled yet -- still need a first Higgsfield image batch and
carousel render before the first post goes out.

## IMPORTANT: two separate Buffer accounts, two separate Chrome profiles
The fitness channels and the recipe-page channels live on **two entirely
separate Buffer accounts** (each capped at 3 channels on Buffer's Free
plan):
- Fitness: Buffer account owned by `workoutnow768@gmail.com`, channels
  30secfitness / 30sec_fitness / Crunch time.
- Recipe: Buffer account owned by `podcasterclips`-linked email, channels
  ai_facts4u / daily_ai_factz / Factual days.

Both stay logged in simultaneously via **two separate Chrome profiles**
on the user's machine (set up 2026-08-22 specifically to avoid having to
log one account out to use the other). When using Claude-in-Chrome
browser automation, use `list_connected_browsers` / `select_browser` to
make sure you're in the correct profile before touching either account's
channels -- **do not** connect a fitness channel while the recipe Buffer
account is open, or vice versa; earlier in this project's life the
fitness channels were briefly (and mistakenly) connected to the recipe
account, which silently disconnected the recipe channels due to the
3-channel cap. Always re-verify the Buffer sidebar shows the expected
channel names for the account you intend to act on before scheduling
anything (same rule as recipe-page, where a wrong-Chrome-profile mixup
once nearly posted to a stranger's account).

## Why a separate project instead of folding into recipe-page
Two independent content pipelines, each with its own rotation index,
schedule, and channel set. Keeping them as sibling projects (same
patterns, separate `state.json`/backup) avoids one pipeline's day_index or
scheduled_up_to accidentally colliding with the other's.

## Content strategy: avoiding repetition
The user flagged early on that pure workout-routine content runs out fast
-- there are only so many distinct exercise circuits before the feed
feels repetitive. The fix baked into `workout_ideas.py`: mix two content
**types** in the same visual carousel format --

- **"routine" posts** -- straight workout circuits (3 exercises + intro
  slide), same shape as recipe-page's recipes.
- **"tip" posts** -- form fixes, myth-busting, common mistakes, recovery
  facts. Same 4-slide format and badge styling, but the content is
  fitness *knowledge* rather than a new physical routine, which is a much
  deeper well to draw from than routines alone. Borrows the spirit of the
  user's existing `daily_ai_factz`/`ai_facts4u` brand -- short, punchy,
  factual -- applied to fitness instead of general trivia.

Target mix (see `state.json`): roughly 2 routines for every 1 tip post.
`workout_ideas.py` starts with 10 routines + 5 tips; grow the tip side
fastest since it doesn't require inventing new physical exercises to stay
fresh -- new facts, myths, and form-check angles on the *same* handful of
core lifts (squat, deadlift, push-up, plank, etc.) go a long way.

## Files
- `scripts/workout_ideas.py` -- the content bank, same shape as
  recipe-page's `recipe_ideas.py` (title, slides list of heading/sub/detail,
  caption, hashtags), plus a `type` field ("routine"/"tip", informational
  only) and optional `badge_step`/`badge_intro` per entry.
- `scripts/make_slides.py` -- copied from recipe-page and extended with
  optional `badge_step`/`badge_intro` params (defaults match recipe-page's
  literal "STEP"/"EASY STEPS" wording, so this is purely additive). Kept
  as a separate copy rather than a shared import so recipe-page's live,
  actively-scheduling pipeline is never at risk from changes made here.
- `scripts/image_prompts.py` -- same pattern as recipe-page's version,
  adapted for fitness/gym photography instead of food photography, and
  branches on `type` ("routine" gets literal exercise-demonstration
  prompts, "tip" gets more symbolic/topical prompts since there's no
  single literal action to photograph for e.g. a myth-busting slide).

## Next steps
1. Verify the new channels appear correctly in Buffer's sidebar (already
   done once 2026-08-22 -- re-check before the actual posting run).
2. Generate real Higgsfield images for the first batch (same
   reliability pattern as recipe-page: Unlimited toggle, fixed Generate
   coordinate, verify via Assets page).
3. Render carousels via `make_slides.render_carousel()`.
4. Visually verify all slides before posting.
5. Schedule via Buffer, same flow as recipe-page (remove any
   unintended default-selected channels, check Instagram's 5-hashtag cap
   via "Customize for each network").
6. Update `state.json` with `status: "live"`, the real `last_day_index`,
   `scheduled_up_to`, etc., matching recipe-page's pattern.
7. Consider whether a shared or separate scheduled-task cadence makes
   sense once both pipelines are live -- they can run independently, but
   coordinate so both don't hit Higgsfield/Buffer at the exact same time.
